<?php
// user/profile_save.php
// Handles all user profile modifications (contact info update, add/delete education, experience, skills)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require __DIR__ . '/../includes/auth_user.php';
require __DIR__ . '/../db.php';
require __DIR__ . '/../includes/helpers.php';

// The user ID from the authenticated session
$uid = (int)($_SESSION['user_id'] ?? 0);
if ($uid === 0) {
    header('Location: /auth/login.php');
    exit;
}

// Ensure the action variable is set
$action = $_POST['action'] ?? '';

// =======================================================
// 1. EDIT CONTACT INFO ACTION
// =======================================================
if ($action === 'edit_contact') {
    $name       = sanitize_input($_POST['name'] ?? '');
    $email      = sanitize_input($_POST['email'] ?? '');
    $phone      = sanitize_input($_POST['phone'] ?? '');
    $areacode   = sanitize_input($_POST['areacode'] ?? '');
    $address    = sanitize_input($_POST['address'] ?? '');
    $address2   = sanitize_input($_POST['address2'] ?? '');
    $city       = sanitize_input($_POST['city'] ?? '');
    $country    = sanitize_input($_POST['country'] ?? '');
    $gender     = sanitize_input($_POST['gender'] ?? '');
    $age        = (int)($_POST['age'] ?? 0);

    $stmt = $conn->prepare("UPDATE users SET 
        name=?, email=?, phone=?, areacode=?, address=?, address2=?, city=?, country=?, gender=?, age=? 
        WHERE id=?");
    
    $stmt->bind_param("sssssssssii", 
        $name, $email, $phone, $areacode, $address, $address2, $city, $country, $gender, $age, $uid);

    if ($stmt->execute()) {
        $_SESSION['message'] = "Personal information updated successfully!";
        $_SESSION['message_type'] = "success";
    } else {
        $_SESSION['message'] = "Error updating personal information: " . $stmt->error;
        $_SESSION['message_type'] = "danger";
    }
    $stmt->close();

// =======================================================
// 2. EDUCATION ACTIONS
// =======================================================
} elseif ($action === 'add_education') {
    $degree = sanitize_input($_POST['degree'] ?? '');
    $institution = sanitize_input($_POST['institution'] ?? '');
    $start_year = sanitize_input($_POST['start_year'] ?? '');
    $end_year = sanitize_input($_POST['end_year'] ?? '');

    $stmt = $conn->prepare("INSERT INTO user_education (user_id, degree, institution, start_year, end_year) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("issss", $uid, $degree, $institution, $start_year, $end_year);

    if ($stmt->execute()) {
        $_SESSION['message'] = "Education entry added.";
        $_SESSION['message_type'] = "success";
    } else {
        $_SESSION['message'] = "Error adding education: " . $stmt->error;
        $_SESSION['message_type'] = "danger";
    }
    $stmt->close();
    
} elseif ($action === 'delete_education') {
    $id = (int)($_POST['id'] ?? 0);
    $stmt = $conn->prepare("DELETE FROM user_education WHERE id=? AND user_id=?");
    $stmt->bind_param("ii", $id, $uid);
    
    if ($stmt->execute()) {
        $_SESSION['message'] = "Education entry deleted.";
        $_SESSION['message_type'] = "success";
    } else {
        $_SESSION['message'] = "Error deleting education: " . $stmt->error;
        $_SESSION['message_type'] = "danger";
    }
    $stmt->close();

// =======================================================
// 3. EXPERIENCE ACTIONS
// =======================================================
} elseif ($action === 'add_experience') {
    $title = sanitize_input($_POST['title'] ?? '');
    $company = sanitize_input($_POST['company'] ?? '');
    $start_year = sanitize_input($_POST['start_year'] ?? '');
    $end_year = sanitize_input($_POST['end_year'] ?? '');
    $description = sanitize_input($_POST['description'] ?? '');

    $stmt = $conn->prepare("INSERT INTO user_experience (user_id, title, company, start_year, end_year, description) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("isssss", $uid, $title, $company, $start_year, $end_year, $description);

    if ($stmt->execute()) {
        $_SESSION['message'] = "Experience entry added.";
        $_SESSION['message_type'] = "success";
    } else {
        $_SESSION['message'] = "Error adding experience: " . $stmt->error;
        $_SESSION['message_type'] = "danger";
    }
    $stmt->close();
    
} elseif ($action === 'delete_experience') {
    $id = (int)($_POST['id'] ?? 0);
    $stmt = $conn->prepare("DELETE FROM user_experience WHERE id=? AND user_id=?");
    $stmt->bind_param("ii", $id, $uid);
    
    if ($stmt->execute()) {
        $_SESSION['message'] = "Experience entry deleted.";
        $_SESSION['message_type'] = "success";
    } else {
        $_SESSION['message'] = "Error deleting experience: " . $stmt->error;
        $_SESSION['message_type'] = "danger";
    }
    $stmt->close();
    
// =======================================================
// 4. SKILL ACTIONS
// =======================================================
} elseif ($action === 'add_skill') {
    $skill_name = sanitize_input($_POST['skill_name'] ?? '');

    $stmt = $conn->prepare("INSERT INTO user_skills (user_id, skill_name) VALUES (?, ?)");
    $stmt->bind_param("is", $uid, $skill_name);

    if ($stmt->execute()) {
        $_SESSION['message'] = "Skill added.";
        $_SESSION['message_type'] = "success";
    } else {
        $_SESSION['message'] = "Error adding skill: " . $stmt->error;
        $_SESSION['message_type'] = "danger";
    }
    $stmt->close();
    
} elseif ($action === 'delete_skill') {
    $id = (int)($_POST['id'] ?? 0);
    $stmt = $conn->prepare("DELETE FROM user_skills WHERE id=? AND user_id=?");
    $stmt->bind_param("ii", $id, $uid);
    
    if ($stmt->execute()) {
        $_SESSION['message'] = "Skill deleted.";
        $_SESSION['message_type'] = "success";
    } else {
        $_SESSION['message'] = "Error deleting skill: " . $stmt->error;
        $_SESSION['message_type'] = "danger";
    }
    $stmt->close();
}

// Redirect back to dashboard
header('Location: /user/dashboard.php');
exit;
?>
