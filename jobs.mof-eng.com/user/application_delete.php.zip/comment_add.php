<?php
require __DIR__ . '/../includes/auth_user.php';
require __DIR__ . '/../db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $uid = (int)$_SESSION['user_id'];
    $appId = (int)($_POST['application_id'] ?? 0);
    $comment = trim($_POST['comment'] ?? '');

    if ($appId > 0 && $comment !== '') {
        $stmt = $conn->prepare("INSERT INTO application_comments (application_id, user_id, author_role, comment, visible_to_applicant) VALUES (?, ?, 'user', ?, 1)");
        $stmt->bind_param("iis", $appId, $uid, $comment);
        $stmt->execute();
    }
}
http_response_code(200);
