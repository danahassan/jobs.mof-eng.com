<?php
// /user/dashboard.php

require __DIR__ . '/../includes/auth_user.php';
require __DIR__ . '/../db.php';
require __DIR__ . '/../includes/helpers.php';

$page_title = "My Dashboard";
include __DIR__ . '/../includes/header.php';

$uid = (int)($_SESSION['user_id'] ?? 0);

/* -------------------------------------------------------
   1) Fetch user record
--------------------------------------------------------*/
$stmt = $conn->prepare("SELECT * FROM users WHERE id=? LIMIT 1");
$stmt->bind_param("i", $uid);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$user) {
    echo '<div class="alert alert-danger mt-4 shadow-sm">User not found or session expired. Please <a href="/auth/login.php">login again</a>.</div>';
    include __DIR__ . '/../includes/footer.php';
    exit;
}

/* -------------------------------------------------------
   2) Fetch profile data (education, experience, skills)
--------------------------------------------------------*/
// Education
$eduStmt = $conn->prepare("SELECT * FROM user_education WHERE user_id=? ORDER BY end_year DESC, id DESC");
$eduStmt->bind_param("i", $uid);
$eduStmt->execute();
$eduRes = $eduStmt->get_result();
$eduStmt->close();

// Experience
$expStmt = $conn->prepare("SELECT * FROM user_experience WHERE user_id=? ORDER BY end_year DESC, id DESC");
$expStmt->bind_param("i", $uid);
$expStmt->execute();
$expRes = $expStmt->get_result();
$expStmt->close();

// Skills
$skillStmt = $conn->prepare("SELECT * FROM user_skills WHERE user_id=? ORDER BY skill_name ASC");
$skillStmt->bind_param("i", $uid);
$skillStmt->execute();
$skillsRes = $skillStmt->get_result();
$skillStmt->close();

/* -------------------------------------------------------
   3) Fetch user's job applications
--------------------------------------------------------*/
$appStmt = $conn->prepare("SELECT * FROM job_applications WHERE user_id=? ORDER BY applied_at DESC");
$appStmt->bind_param("i", $uid);
$appStmt->execute();
$apps = $appStmt->get_result();
$appStmt->close();
?>
<style>
.dashboard-header { font-weight: 800; color: #198754; margin-bottom: 1.8rem; }
.profile-card { border: none; border-radius: .8rem; box-shadow: 0 3px 12px rgba(0,0,0,0.08); overflow: hidden; }
.profile-header { background: linear-gradient(90deg,#198754,#28a745); color:#fff; text-align:center; padding:2rem 1rem; }
.profile-header img { width:120px; height:120px; border-radius:50%; border:4px solid #fff; object-fit:cover; margin-bottom:.8rem; }
.profile-body { padding:1.8rem; background:#fff; }
.profile-section { margin-bottom:1.5rem; }
.profile-section h6 { font-weight:700; color:#198754; border-bottom:2px solid #d1f2e4; display:inline-block; padding-bottom:.3rem; margin-bottom:.7rem; }
.skill-badge { background:#e9f7ef; color:#198754; border-radius:20px; padding:.3rem .75rem; font-size:.85rem; font-weight:600; margin:.2rem; display:inline-block; }
.application-item { border:1px solid #e9ecef; border-radius:.7rem; padding:1.3rem; background:#fff; margin-bottom:1.5rem; box-shadow:0 2px 6px rgba(0,0,0,0.05); }
.app-title { color:#0d6efd; font-weight:600; }
.app-details { color:#666; font-size:.9rem; }
.info-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(230px,1fr)); gap:.5rem; }
.info-grid div { background:#f8f9fa; border-radius:.4rem; padding:.4rem .6rem; font-size:.9rem; }
.comment-box { background:#f9f9f9; padding:.8rem 1rem; border-radius:.5rem; margin-top:.8rem; }
.comment-box.admin { border-left:4px solid #0d6efd; }
.comment-box.user { border-left:4px solid #198754; }
</style>

<h3 class="dashboard-header">Welcome, <?= strtoupper(e($user['name'])) ?></h3>

<div class="row g-4">

    <!-- LEFT: Profile -->
    <div class="col-lg-4">
        <div class="card profile-card">
            <div class="profile-header">
                <img src="<?= e($user['profile_photo_path'] ?: '/uploads/profiles/default.png') ?>" alt="Profile Photo">
                <h4><?= e($user['name']) ?></h4>
                <p><?= e($user['email']) ?></p>
            </div>

            <div class="profile-body">
                <!-- Personal info -->
                <div class="profile-section">
                    <h6><i class="bi bi-person-lines-fill"></i> Personal Info</h6>
                    <p><i class="bi bi-telephone"></i>
                        <?php
                        $phone_number = e($user['phone'] ?? '—');
                        if (!empty($user['areacode'])) $phone_number = "(" . e($user['areacode']) . ") " . $phone_number;
                        echo $phone_number;
                        ?>
                    </p>
                    <p><i class="bi bi-geo-alt"></i>
                        <?php
                        $address_parts = [];
                        foreach (['address','address2','city','country'] as $f) {
                            if (!empty($user[$f])) $address_parts[] = e($user[$f]);
                        }
                        echo implode(', ', $address_parts) ?: '—';
                        ?>
                    </p>
                    <p><i class="bi bi-gender-ambiguous"></i> Gender: <?= e(ucfirst($user['gender'] ?? '—')) ?></p>
                    <p><i class="bi bi-calendar"></i> Age: <?= e($user['age'] ?? '—') ?></p>
                </div>

                <div class="text-center mb-4">
                    <a href="/user/profile_edit.php" class="btn btn-sm btn-outline-primary">
                        <i class="bi bi-pencil-square"></i> Edit Contact Info
                    </a>
                </div>

                <!-- Education -->
                <div class="profile-section">
                    <h6><i class="bi bi-mortarboard"></i> Education</h6>
                    <?php if ($eduRes->num_rows > 0): while($edu = $eduRes->fetch_assoc()): ?>
                        <div class="d-flex justify-content-between align-items-center border-bottom py-1">
                            <div>
                                <strong><?= e($edu['degree']) ?></strong><br>
                                <small><?= e($edu['institution']) ?> (<?= e($edu['start_year']) ?> - <?= e($edu['end_year']) ?>)</small>
                            </div>
                            <form method="post" action="/user/profile_save.php" class="m-0" onsubmit="return confirm('Delete this education entry?');">
                                <input type="hidden" name="action" value="delete_education">
                                <input type="hidden" name="id" value="<?= e($edu['id']) ?>">
                                <button type="submit" class="btn btn-sm btn-link text-danger p-0"><i class="bi bi-trash"></i></button>
                            </form>
                        </div>
                    <?php endwhile; else: ?>
                        <p class="text-muted small">No education entries added.</p>
                    <?php endif; ?>

                    <form method="post" action="/user/profile_save.php" class="mt-3">
                        <input type="hidden" name="action" value="add_education">
                        <input type="text" name="degree" class="form-control mb-1" placeholder="Degree/Certificate" required>
                        <input type="text" name="institution" class="form-control mb-1" placeholder="Institution/University" required>
                        <div class="d-flex gap-1">
                            <input type="text" name="start_year" class="form-control" placeholder="Start Year" required pattern="\d{4}">
                            <input type="text" name="end_year" class="form-control" placeholder="End Year (or Present)" required>
                        </div>
                        <button type="submit" class="btn btn-sm btn-outline-success w-100 mt-2"><i class="bi bi-plus-circle"></i> Add Education</button>
                    </form>
                </div>

                <!-- Experience -->
                <div class="profile-section">
                    <h6><i class="bi bi-briefcase"></i> Experience</h6>
                    <?php if ($expRes->num_rows > 0): while($exp = $expRes->fetch_assoc()): ?>
                        <div class="d-flex justify-content-between align-items-start border-bottom py-1">
                            <div>
                                <strong><?= e($exp['title']) ?></strong> at <?= e($exp['company']) ?><br>
                                <small><?= e($exp['start_year']) ?> - <?= e($exp['end_year']) ?></small>
                                <p class="text-muted small mb-0"><?= nl2br(e($exp['description'])) ?></p>
                            </div>
                            <form method="post" action="/user/profile_save.php" class="m-0" onsubmit="return confirm('Delete this experience entry?');">
                                <input type="hidden" name="action" value="delete_experience">
                                <input type="hidden" name="id" value="<?= e($exp['id']) ?>">
                                <button type="submit" class="btn btn-sm btn-link text-danger p-0"><i class="bi bi-trash"></i></button>
                            </form>
                        </div>
                    <?php endwhile; else: ?>
                        <p class="text-muted small">No work experience added.</p>
                    <?php endif; ?>

                    <form method="post" action="/user/profile_save.php" class="mt-3">
                        <input type="hidden" name="action" value="add_experience">
                        <input type="text" name="title" class="form-control mb-1" placeholder="Job Title" required>
                        <input type="text" name="company" class="form-control mb-1" placeholder="Company Name" required>
                        <div class="d-flex gap-1">
                            <input type="text" name="start_year" class="form-control" placeholder="Start Year" required pattern="\d{4}">
                            <input type="text" name="end_year" class="form-control" placeholder="End Year (or Present)" required>
                        </div>
                        <textarea name="description" class="form-control mt-1" placeholder="Short description of duties (optional)"></textarea>
                        <button type="submit" class="btn btn-sm btn-outline-success w-100 mt-2"><i class="bi bi-plus-circle"></i> Add Experience</button>
                    </form>
                </div>

                <!-- Skills -->
                <div class="profile-section mb-0">
                    <h6><i class="bi bi-stars"></i> Skills</h6>
                    <div>
                        <?php if ($skillsRes->num_rows > 0): while($s = $skillsRes->fetch_assoc()): ?>
                            <span class="skill-badge">
                                <?= e($s['skill_name']) ?>
                                <form method="post" action="/user/profile_save.php" style="display:inline;" onsubmit="return confirm('Remove skill: <?= e($s['skill_name']) ?>?');">
                                    <input type="hidden" name="action" value="delete_skill">
                                    <input type="hidden" name="id" value="<?= e($s['id']) ?>">
                                    <button type="submit" class="btn btn-link text-danger p-0 ms-1" style="line-height:1;"><i class="bi bi-x"></i></button>
                                </form>
                            </span>
                        <?php endwhile; else: ?>
                            <p class="text-muted small">No skills added yet.</p>
                        <?php endif; ?>
                    </div>

                    <form method="post" action="/user/profile_save.php" class="mt-3 d-flex">
                        <input type="hidden" name="action" value="add_skill">
                        <input type="text" name="skill_name" class="form-control me-1" placeholder="New Skill (e.g., PHP, AutoCAD)" required>
                        <button type="submit" class="btn btn-sm btn-success"><i class="bi bi-plus-lg"></i> Add</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- RIGHT: Applications -->
    <div class="col-lg-8">
        <?php if (!empty($_SESSION['message'])): ?>
            <div class="alert alert-<?= e($_SESSION['message_type'] ?? 'info') ?> alert-dismissible fade show shadow-sm">
                <?= e($_SESSION['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php unset($_SESSION['message'], $_SESSION['message_type']); ?>
        <?php endif; ?>

        <div class="card">
            <div class="card-header bg-white fw-semibold d-flex justify-content-between align-items-center">
                <span><i class="bi bi-briefcase-fill text-success me-2"></i> My Job Applications</span>
                <a href="/jobs.php" class="btn btn-sm btn-success"><i class="bi bi-plus-circle"></i> Apply New</a>
            </div>

            <div class="card-body">
                <?php if ($apps->num_rows > 0): ?>
                    <?php while ($app = $apps->fetch_assoc()): ?>
                        <?php
                        $appId = (int)$app['id'];
                        $badgeClass = match($app['status']) {
                            'Hired' => 'success',
                            'Interview' => 'info',
                            'Offer' => 'primary',
                            'Rejected' => 'danger',
                            'Screening' => 'warning',
                            default => 'secondary'
                        };

                        // Visible comments (user + public admin)
                        $cStmt = $conn->prepare("SELECT * FROM application_comments WHERE application_id=? AND (author_role='user' OR visible_to_applicant=1) ORDER BY created_at ASC");
                        $cStmt->bind_param("i", $appId);
                        $cStmt->execute();
                        $comments = $cStmt->get_result();
                        $cStmt->close();
                        ?>
                        <div class="application-item">
                            <div class="d-flex justify-content-between flex-wrap align-items-start">
                                <div>
                                    <div class="app-title"><i class="bi bi-person-workspace me-1"></i> <?= e($app['position']) ?: 'N/A' ?></div>
                                    <div class="app-details">Applied: <?= e(date('M d, Y', strtotime($app['applied_at']))) ?> • Source: <?= e($app['source']) ?></div>
                                </div>
                                <span class="badge bg-<?= $badgeClass ?>"><?= e($app['status']) ?></span>
                            </div>

                            <hr class="my-3">

                            <div class="info-grid">
                                <div><strong>Experience:</strong> <?= e($app['years_experience'] ?: '—') ?> yrs</div>
                                <div><strong>Expected Salary:</strong> <?= e($app['expected_salary'] ? number_format($app['expected_salary']) . ' USD' : '—') ?></div>
                                <div><strong>Start Date:</strong> <?= e(($app['startdate'] && $app['startdate'] !== '0000-00-00') ? date('M d, Y', strtotime($app['startdate'])) : '—') ?></div>
                                <div><strong>Resume:</strong> <?= e($app['cv_filename'] ?: 'N/A') ?></div>
                            </div>

                            <?php if ($app['cv_filename']): ?>
                                <div class="mt-2 text-end">
                                    <a href="<?= e($app['resume_path']) ?>" target="_blank" class="btn btn-sm btn-outline-primary">
                                        <i class="bi bi-file-earmark-arrow-down"></i> View Resume
                                    </a>
                                </div>
                            <?php endif; ?>

                            <?php if (!empty($app['message'])): ?>
                                <div class="mt-3"><strong>Cover Letter:</strong><br><?= nl2br(e($app['message'])) ?></div>
                            <?php endif; ?>

                            <!-- Edit/Delete controls -->
                            <div class="mt-3 d-flex justify-content-end gap-2">
                                <button class="btn btn-sm btn-outline-primary" type="button" data-bs-toggle="collapse" data-bs-target="#editForm<?= $appId ?>">
                                    <i class="bi bi-pencil-square"></i> Edit
                                </button>
                                <form method="post" action="/user/application_save.php" onsubmit="return confirm('Delete this application?');">
                                    <input type="hidden" name="action" value="delete_application">
                                    <input type="hidden" name="id" value="<?= e($appId) ?>">
                                    <button type="submit" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i> Delete</button>
                                </form>
                            </div>

                            <!-- Inline Edit Form -->
                            <div class="collapse mt-3" id="editForm<?= $appId ?>">
                                <form method="post" action="/user/application_save.php" class="border rounded p-3 bg-light">
                                    <input type="hidden" name="action" value="edit_application">
                                    <input type="hidden" name="id" value="<?= e($appId) ?>">

                                    <div class="row g-2">
                                        <div class="col-md-6">
                                            <label class="form-label fw-bold small">Position</label>
                                            <input type="text" name="position" class="form-control form-control-sm" value="<?= e($app['position']) ?>" required>
                                        </div>
                                        <div class="col-md-3">
                                            <label class="form-label fw-bold small">Experience (yrs)</label>
                                            <input type="number" name="years_experience" class="form-control form-control-sm" value="<?= e($app['years_experience']) ?>">
                                        </div>
                                        <div class="col-md-3">
                                            <label class="form-label fw-bold small">Expected Salary</label>
                                            <input type="number" step="0.01" name="expected_salary" class="form-control form-control-sm" value="<?= e($app['expected_salary']) ?>">
                                        </div>
                                    </div>

                                    <div class="mt-2">
                                        <label class="form-label fw-bold small">Message / Cover Letter</label>
                                        <textarea name="message" class="form-control form-control-sm" rows="2"><?= e($app['message']) ?></textarea>
                                    </div>

                                    <div class="text-end mt-2">
                                        <button type="submit" class="btn btn-sm btn-success"><i class="bi bi-save"></i> Save Changes</button>
                                    </div>
                                </form>
                            </div>

                            <!-- Comments -->
                            <div class="mt-4">
                                <h6 class="fw-bold text-success"><i class="bi bi-chat-dots"></i> Application Comments</h6>
                                <div id="comments-list-<?= $appId ?>">
                                    <?php if ($comments->num_rows > 0): ?>
                                        <?php while ($c = $comments->fetch_assoc()): ?>
                                            <div class="comment-box <?= $c['author_role'] ?>">
                                                <div class="comment-author"><?= $c['author_role'] === 'admin' ? 'Admin' : 'You' ?></div>
                                                <div class="comment-date"><?= e(date('M d, Y H:i', strtotime($c['created_at']))) ?></div>
                                                <div><?= nl2br(e($c['comment'])) ?></div>
                                            </div>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <p class="text-muted small">No visible comments yet.</p>
                                    <?php endif; ?>
                                </div>

                                <!-- Add comment -->
                                <form class="comment-form mt-3" method="post" onsubmit="return submitComment(this, <?= $appId ?>);">
                                    <textarea name="comment" class="form-control mb-2" placeholder="Write a comment for the hiring team..." required></textarea>
                                    <button class="btn btn-sm btn-outline-success"><i class="bi bi-send"></i> Post Comment</button>
                                </form>
                            </div>
                        </div>
                    <?php endwhile; else: ?>
                        <div class="text-center text-muted py-5">
                            <i class="bi bi-folder2-open display-4 text-secondary"></i>
                            <p class="mt-3">You haven't submitted any job applications yet.</p>
                            <a href="/jobs.php" class="btn btn-primary mt-2"><i class="bi bi-search"></i> Find Jobs</a>
                        </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
/**
 * Simple in-page message display (used by comment submit)
 */
function showMessage(message, type = 'info') {
    const container = document.querySelector('.col-lg-8 .card .card-body') || document.body;
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show shadow-sm`;
    alertDiv.setAttribute('role', 'alert');
    alertDiv.innerHTML = `${message}<button type="button" class="btn-close" data-bs-dismiss="alert"></button>`;
    container.prepend(alertDiv);
    setTimeout(() => {
        try { new bootstrap.Alert(alertDiv).close(); } catch(e){}
    }, 4000);
}

/**
 * AJAX comment submit to /user/comment_add.php (server must accept: application_id, author_role, user_id, comment)
 */
async function submitComment(form, appId) {
    const button = form.querySelector('button');
    const original = button.innerHTML;
    button.disabled = true;
    button.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Posting...';

    const fd = new FormData(form);
    fd.append('application_id', appId);
    fd.append('author_role', 'user');
    fd.append('user_id', <?= (int)$uid ?>);

    try {
        const res = await fetch('/user/comment_add.php', { method: 'POST', body: fd });
        if (res.ok) {
            showMessage('Comment posted successfully!', 'success');
            setTimeout(() => { location.reload(); }, 1200);
        } else {
            const t = await res.text();
            showMessage('Failed to post comment: ' + t.substring(0, 100), 'danger');
            button.disabled = false;
            button.innerHTML = original;
        }
    } catch (err) {
        console.error(err);
        showMessage('Network error while posting the comment.', 'danger');
        button.disabled = false;
        button.innerHTML = original;
    }
    return false;
}
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
