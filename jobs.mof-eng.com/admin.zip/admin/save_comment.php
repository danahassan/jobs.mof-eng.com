<?php
require __DIR__ . '/../includes/auth_admin.php';
require __DIR__ . '/../db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $application_id = (int)($_POST['application_id'] ?? 0);
    $comment = trim($_POST['comment'] ?? '');
    $visibility = $_POST['visibility'] === 'public' ? 'public' : 'private';
    $admin_name = $_SESSION['name'] ?? 'Admin';

    if ($application_id > 0 && $comment !== '') {
        $stmt = $conn->prepare("INSERT INTO admin_comments (application_id, admin_name, comment, visibility) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("isss", $application_id, $admin_name, $comment, $visibility);
        $stmt->execute();
        $stmt->close();
    }
}

header("Location: /admin/application_detail.php?id=" . urlencode($application_id));
exit;
?>
