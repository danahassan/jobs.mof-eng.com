<?php
require __DIR__ . '/../includes/auth_admin.php';
require __DIR__ . '/../db.php';
$page_title = "User Profile";
include __DIR__ . '/../includes/header.php';

$uid = (int)($_GET['id'] ?? 0);
$u = $conn->query("SELECT * FROM users WHERE id=$uid")->fetch_assoc();
if (!$u){ echo "<p>User not found.</p>"; include __DIR__ . '/../includes/footer.php'; exit; }
$comments = $conn->query("SELECT uc.*, a.name admin_name FROM user_comments uc JOIN users a ON a.id=uc.admin_id WHERE uc.user_id=$uid ORDER BY uc.created_at DESC");
$app = $conn->query("SELECT * FROM job_applications WHERE user_id=$uid ORDER BY applied_at DESC LIMIT 1")->fetch_assoc();
?>
<div class="d-flex align-items-center mb-3">
  <img class="avatar me-3" src="<?= e($u['profile_photo_path'] ?: '/uploads/profiles/default.png') ?>">
  <div>
    <h4 class="mb-0"><?= e($u['name']) ?></h4>
    <div class="text-muted small"><?= e($u['email']) ?> • <?= e($u['role']) ?></div>
  </div>
</div>

<?php if($app): ?>
<div class="card mb-3"><div class="card-header bg-light fw-semibold">Latest Application</div>
<div class="card-body">
  <div class="row">
    <div class="col-md-4"><strong>Position:</strong> <?= e($app['position']) ?></div>
    <div class="col-md-4"><strong>Status:</strong> <?= e($app['status']) ?></div>
    <div class="col-md-4"><strong>Source:</strong> <?= e($app['source']) ?></div>
    <div class="col-md-4"><strong>Experience:</strong> <?= e($app['years_experience']) ?> yrs</div>
    <div class="col-md-4"><strong>Expected Salary:</strong> <?= e($app['expected_salary']) ?></div>
  </div>
</div></div>
<?php endif; ?>

<div class="row g-3">
  <div class="col-lg-6">
    <div class="card">
      <div class="card-header bg-light fw-semibold">Add Comment</div>
      <div class="card-body">
        <form method="post" action="/api/user_comments.php">
          <input type="hidden" name="user_id" value="<?= $uid ?>">
          <div class="mb-2"><textarea name="comment" class="form-control" rows="3" required></textarea></div>
          <button class="btn btn-primary">Save Comment</button>
        </form>
      </div>
    </div>
  </div>
  <div class="col-lg-6">
    <div class="card">
      <div class="card-header bg-light fw-semibold">Comments</div>
      <div class="card-body">
        <?php while($c=$comments->fetch_assoc()): ?>
          <div class="mb-2 border rounded p-2">
            <div class="small text-muted"><?= e($c['created_at']) ?> • <?= e($c['admin_name']) ?></div>
            <div><?= nl2br(e($c['comment'])) ?></div>
          </div>
        <?php endwhile; ?>
      </div>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
