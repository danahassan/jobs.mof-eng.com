<?php
// Configuration to display all errors (Good for development/debugging 500 errors)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Includes needed for both AJAX and HTML view.
require __DIR__ . '/../includes/auth_admin.php';
require __DIR__ . '/../db.php';
require __DIR__ . '/../includes/helpers.php'; // Assumed to contain e() for escaping HTML

/* ---------------------------------------------------------------
   1) AJAX HANDLERS - MUST EXECUTE AND EXIT IMMEDIATELY
---------------------------------------------------------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');

    // Utility function to handle error exits
    $errorExit = function ($msg) {
        echo json_encode(['ok' => false, 'message' => $msg]);
        exit; // CRITICAL: Stop script execution for AJAX requests
    };

    // Utility function to handle success exits
    $successExit = function ($msg) {
        echo json_encode(['ok' => true, 'message' => $msg]);
        exit; // CRITICAL: Stop script execution for AJAX requests
    };

    // CRITICAL STABILIZATION: Wrap all AJAX processing in try-catch to guarantee JSON response
    try {
        $act = $_POST['action'];

        if ($act === 'add') {
            $name = trim($_POST['position_name'] ?? '');
            $qty  = (int)($_POST['quantity'] ?? 1);

            // Input validation
            if ($name === '' || $qty < 1) {
                $errorExit('Invalid position name or quantity.');
            }

            // Check if position already exists
            $checkStmt = $conn->prepare("SELECT id FROM job_positions WHERE position_name = ?");
            $checkStmt->bind_param("s", $name);
            $checkStmt->execute();
            $result = $checkStmt->get_result();

            if ($result->num_rows > 0) {
                $errorExit('Position already exists.');
            }

            // Insert new position
            $stmt = $conn->prepare("INSERT INTO job_positions (position_name, quantity, status) VALUES (?, ?, 'active')");
            $stmt->bind_param("si", $name, $qty);
            $success = $stmt->execute();

            $success ? $successExit('Position added successfully.') : $errorExit('Failed to add position.');
        }

        if ($act === 'edit') {
            $id    = (int)($_POST['id'] ?? 0);
            $name = trim($_POST['position_name'] ?? '');
            $qty  = (int)($_POST['quantity'] ?? 1);

            if ($id <= 0 || $name === '' || $qty < 1) {
                $errorExit('Invalid input for edit.');
            }

            $stmt = $conn->prepare("UPDATE job_positions SET position_name=?, quantity=? WHERE id=?");
            $stmt->bind_param("sii", $name, $qty, $id);
            $success = $stmt->execute();

            $success ? $successExit('Position updated.') : $errorExit('Failed to update position.');
        }

        if ($act === 'toggle') {
            $id    = (int)($_POST['id'] ?? 0);
            $new  = ($_POST['new_status'] ?? 'inactive') === 'active' ? 'active' : 'inactive';

            if ($id <= 0) {
                $errorExit('Invalid ID for toggle.');
            }

            $stmt = $conn->prepare("UPDATE job_positions SET status=? WHERE id=?");
            $stmt->bind_param("si", $new, $id);
            $success = $stmt->execute();

            $success ? $successExit('Status changed to ' . ucfirst($new) . '.') : $errorExit('Failed to toggle status.');
        }

        if ($act === 'delete') {
            $id = (int)($_POST['id'] ?? 0);

            if ($id <= 0) {
                $errorExit('Invalid ID for delete.');
            }

            $stmt = $conn->prepare("DELETE FROM job_positions WHERE id=?");
            $stmt->bind_param("i", $id);
            $success = $stmt->execute();

            // NOTE: Does not delete associated job_applications records (as per original code comment)

            $success ? $successExit('Position deleted.') : $errorExit('Failed to delete position.');
        }

        if ($act === 'fetch_applicants') {
            $pos = trim($_POST['position'] ?? '');

            if ($pos === '') {
                $errorExit('Missing position name.');
            }

            $stmt = $conn->prepare("
                SELECT firstname, lastname, email, phone, status, applied_at
                FROM job_applications
                WHERE LOWER(TRIM(position)) = LOWER(TRIM(?))
                ORDER BY applied_at DESC
            ");

            if (!$stmt) {
                 $errorExit("Failed to prepare SQL statement: " . $conn->error);
            }

            $stmt->bind_param("s", $pos);

            // Check execution success
            if (!$stmt->execute()) {
                 $errorExit("Database query failed to execute: " . $stmt->error);
            }

            $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            echo json_encode(['ok' => true, 'data' => $rows]);
            exit; // CRITICAL: Exit after successful data fetch
        }

        $errorExit('Unknown action');

    } catch (\Throwable $e) {
        // Catch any fatal errors/exceptions not handled by prepare/execute checks and return JSON error
        $errorExit('A critical server exception occurred: ' . $e->getMessage());
    }
}

/* ---------------------------------------------------------------
   2) FETCH DATA & HTML VIEW GENERATION (ONLY runs if NOT AJAX)
---------------------------------------------------------------- */

$page_title = "Job Positions Management";
include __DIR__ . '/../includes/header.php'; // HTML output starts here!

// Main table data fetch
// MODIFIED: Changed ORDER BY to 'jp.id DESC' to sort by newest first.
$rows = $conn->query("
    SELECT jp.id, jp.position_name, jp.quantity, jp.status,
           COUNT(ja.id) AS applicants
    FROM job_positions jp
    LEFT JOIN job_applications ja
      ON LOWER(TRIM(ja.position)) = LOWER(TRIM(jp.position_name))
    GROUP BY jp.id
    ORDER BY jp.id DESC
");

// Stats for overview cards - Using individual queries for clarity, ensuring proper error handling via COALESCE and NULL checks.
$stats = [
  // Total positions created
  'positions' => (int)($conn->query("SELECT COUNT(*) c FROM job_positions")->fetch_assoc()['c'] ?? 0),
  // Sum of vacancies in ACTIVE positions only
  'vacancies' => (int)($conn->query("SELECT COALESCE(SUM(quantity),0) q FROM job_positions WHERE status='active'")->fetch_assoc()['q'] ?? 0),
  // Total applications received (more accurate total, regardless of position status)
  'apps' => (int)($conn->query("SELECT COUNT(*) c FROM job_applications")->fetch_assoc()['c'] ?? 0),
  // Count of active positions
  'active_pos_count' => (int)($conn->query("SELECT COUNT(*) AS c FROM job_positions WHERE status='active'")->fetch_assoc()['c'] ?? 0)
];
?>

<!-- --- HTML CONTENT --- -->
<style>
/* --- Professional Overview Card Styling --- */
.overview-card {
  border: none;
  color: #fff;
  border-radius: 14px;
  transition: transform 0.2s ease, box-shadow 0.2s ease;
}
.overview-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 10px 20px rgba(0,0,0,0.15);
}
.overview-icon {
  font-size: 2.5rem;
  opacity: 0.8;
}
.bg-gradient-blue { background: linear-gradient(135deg, #007bff, #00a3ff); }
.bg-gradient-green { background: linear-gradient(135deg, #28a745, #20c997); }
.bg-gradient-purple { background: linear-gradient(135deg, #6f42c1, #9b59b6); }
.bg-gradient-orange { background: linear-gradient(135deg, #fd7e14, #f39c12); }
.card-label {
  font-size: 0.9rem;
  opacity: 0.9;
  letter-spacing: .5px;
}
.card-value {
  font-size: 2rem;
  font-weight: 700;
}
/* Spinner styling for buttons */
.btn .spinner-border {
  width: 1rem;
  height: 1rem;
  margin-right: 0.5rem;
}
</style>

<h3 class="fw-bold mb-4 text-dark">Job Positions Overview</h3>
<div class="row g-3 mb-4">
  <div class="col-md-4 col-lg-3">
    <div class="card overview-card bg-gradient-blue shadow-sm text-center">
      <div class="card-body">
        <i class="bi bi-briefcase overview-icon mb-2"></i>
        <div class="card-label">Total Positions</div>
        <div class="card-value"><?= $stats['positions'] ?></div>
      </div>
      <div class="card-footer bg-transparent border-0 text-white-50 small">All created job listings</div>
    </div>
  </div>
  <div class="col-md-4 col-lg-3">
    <div class="card overview-card bg-gradient-green shadow-sm text-center">
      <div class="card-body">
        <i class="bi bi-person-lines-fill overview-icon mb-2"></i>
        <div class="card-label">Total Vacancies</div>
        <div class="card-value"><?= $stats['vacancies'] ?></div>
      </div>
      <div class="card-footer bg-transparent border-0 text-white-50 small">Open slots in active positions</div>
    </div>
  </div>
  <div class="col-md-4 col-lg-3">
    <div class="card overview-card bg-gradient-purple shadow-sm text-center">
      <div class="card-body">
        <i class="bi bi-people-fill overview-icon mb-2"></i>
        <div class="card-label">Total Applicants</div>
        <div class="card-value"><?= $stats['apps'] ?></div>
      </div>
      <div class="card-footer bg-transparent border-0 text-white-50 small">Total applications received</div>
    </div>
  </div>
  <div class="col-md-4 col-lg-3">
    <div class="card overview-card bg-gradient-orange shadow-sm text-center">
      <div class="card-body">
        <i class="bi bi-bar-chart-line-fill overview-icon mb-2"></i>
        <div class="card-label">Active Positions</div>
        <div class="card-value">
          <?= $stats['active_pos_count'] ?>
        </div>
      </div>
      <div class="card-footer bg-transparent border-0 text-white-50 small">Currently visible to candidates</div>
    </div>
  </div>
</div>

<!-- Global Status Message Area -->
<div id="statusMessage" class="mb-4"></div>

<!-- Add New Job Position -->
<div class="card border-0 shadow-sm mb-4">
  <div class="card-header bg-light fw-semibold">Add New Job Position</div>
  <div class="card-body">
    <form id="addForm" class="row g-3">
      <div class="col-md-6">
        <label class="form-label">Position Name</label>
        <input name="position_name" class="form-control" placeholder="e.g. Safety Officer" required>
      </div>
      <div class="col-md-3">
        <label class="form-label">Vacancies</label>
        <input type="number" name="quantity" class="form-control" min="1" value="1" required>
      </div>
      <div class="col-md-3 align-self-end">
        <button type="submit" class="btn btn-primary w-100" id="addBtn">
          <i class="bi bi-plus-circle"></i> Add Position
        </button>
      </div>
    </form>
  </div>
</div>

<!-- Manage Job Positions -->
<div class="card border-0 shadow-sm mb-4">
  <div class="card-header bg-light fw-semibold">Manage Job Positions</div>
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-bordered align-middle text-center" id="posTable">
        <thead class="table-light">
          <tr>
            <th>#</th>
            <th>Position</th>
            <th>Vacancies</th>
            <th>Applicants</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php 
          // Initialize sequential counter
          $i = 1; 
          while ($r = $rows->fetch_assoc()): ?>
          <tr data-id="<?= e($r['id']) ?>" data-position="<?= e($r['position_name']) ?>">
            <td><?= $i++ ?></td> <!-- Display sequential number -->
            <td class="pos-name text-start"><?= e($r['position_name']) ?></td>
            <td class="pos-qty"><?= e($r['quantity']) ?></td>
            <td>
              <span class="badge applicants-badge <?= $r['applicants'] > 0 ? 'bg-primary' : 'text-muted bg-light' ?>">
                <?= $r['applicants'] ?>
              </span>
            </td>
            <td>
              <span class="badge bg-<?= ($r['status']==='active' ? 'success' : 'secondary') ?> status">
                <?= ucfirst($r['status']) ?>
              </span>
            </td>
            <td>
              <button type="button" class="btn btn-sm btn-outline-info viewBtn" title="View Applicants" <?= $r['applicants'] == 0 ? 'disabled' : '' ?>>
                <i class="bi bi-eye"></i>
              </button>
              <button type="button" class="btn btn-sm btn-outline-primary editBtn" title="Edit Position">
                <i class="bi bi-pencil"></i>
              </button>
              <button type="button" class="btn btn-sm btn-outline-warning toggleBtn" title="Toggle Status (Active/Inactive)">
                <i class="bi bi-power"></i>
              </button>
              <button type="button" class="btn btn-sm btn-outline-danger delBtn" title="Delete Position">
                <i class="bi bi-trash"></i>
              </button>
            </td>
          </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Applicants per Position Chart -->
<div class="card border-0 shadow-sm mb-5">
  <div class="card-header bg-light fw-semibold">Applicants per Position</div>
  <div class="card-body">
    <canvas id="posChart" height="120"></canvas>
  </div>
</div>

<!-- EDIT MODAL -->
<div class="modal fade" id="editModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form id="editForm">
        <div class="modal-header">
          <h5 class="modal-title">Edit Position</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <input type="hidden" name="id" id="edit-id">
          <div class="mb-3">
            <label class="form-label">Position Name</label>
            <input type="text" name="position_name" id="edit-name" class="form-control" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Vacancies</label>
            <input type="number" name="quantity" id="edit-qty" class="form-control" min="1" required>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary" id="editBtn">Save Changes</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- VIEW APPLICANTS MODAL -->
<div class="modal fade" id="applicantsModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-xl modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header d-flex justify-content-between align-items-center">
        <h5 class="modal-title flex-grow-1">Applicants for: <span id="applicantPosTitle" class="fw-bold"></span></h5>
        <!-- CSV Download Button -->
        <button id="downloadCsvBtn" class="btn btn-success btn-sm me-3" style="display:none;" title="Download Data as CSV">
          <i class="bi bi-file-earmark-arrow-down"></i> Download CSV
        </button>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body" id="applicantsBody">
        <p class="text-center text-muted"><i class="bi bi-arrow-clockwise spinner-border spinner-border-sm me-2"></i> Loading Applicants...</p>
      </div>
    </div>
  </div>
</div>

<!-- GENERIC CONFIRMATION MODAL (Replaces confirm() function) -->
<div class="modal fade" id="confirmationModal" tabindex="-1" aria-labelledby="confirmationModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-header bg-danger text-white">
        <h5 class="modal-title" id="confirmationModalLabel">Confirmation</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="confirmationModalBody">
        <!-- Content inserted by JS -->
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-danger" id="confirmActionBtn">Confirm</button>
      </div>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
// Bootstrap dependency is assumed to be loaded by header/footer

// Global variables to hold data for CSV download
window.currentApplicantsData = [];
window.currentPositionName = '';

/* ---------------------------------------------------------------
   UX AND UTILITY HELPERS
---------------------------------------------------------------- */
/** Shows a transient message alert. */
function showMessage(type, message, duration = 3000) {
    const container = document.getElementById('statusMessage');
    const alertHtml = `<div class="alert alert-${type} alert-dismissible fade show" role="alert">${message}
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>`;
    container.innerHTML = alertHtml;
    setTimeout(() => {
        const alert = container.querySelector('.alert');
        if (alert) {
            // Check if bootstrap is available before trying to close
            if (typeof bootstrap !== 'undefined' && bootstrap.Alert) {
                new bootstrap.Alert(alert).close();
            } else {
                alert.remove();
            }
        }
    }, duration);
}

/** Toggles loading state on a button. */
function toggleLoading(btn, isLoading, defaultText) {
    const icon = btn.querySelector('i');
    const spinner = `<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>`;
    btn.disabled = isLoading;
    if (isLoading) {
        btn.setAttribute('data-original-html', btn.innerHTML); // Store original content
        btn.innerHTML = spinner + ' Processing...';
    } else {
        btn.innerHTML = btn.getAttribute('data-original-html') || defaultText;
        btn.removeAttribute('data-original-html');
    }
}

/** Draws the Chart.js graph. */
function drawChart(){
    const ctx = document.getElementById('posChart');
    if (!ctx) return;
    const labels = [...document.querySelectorAll('#posTable tbody .pos-name')].map(td => td.innerText.trim());
    const data = [...document.querySelectorAll('#posTable tbody tr')].map(tr => {
        const b = tr.querySelector('.applicants-badge'); return b ? parseInt(b.innerText, 10) : 0;
    });
    if (window.posChartObj) window.posChartObj.destroy();
    window.posChartObj = new Chart(ctx, {
        type: 'bar',
        data: { labels, datasets: [{ label: 'Applicants', data, backgroundColor: '#0d6efd' }] },
        options: { responsive: true, scales: { y: { beginAtZero: true } } }
    });
}

/** Shows the custom confirmation modal and executes a callback on confirm. */
function showConfirmation(title, body, confirmCallback) {
    const modalEl = document.getElementById('confirmationModal');
    const titleEl = document.getElementById('confirmationModalLabel');
    const bodyEl = document.getElementById('confirmationModalBody');
    const confirmBtn = document.getElementById('confirmActionBtn');

    titleEl.textContent = title;
    bodyEl.innerHTML = body;

    // Remove previous listeners to prevent multiple calls
    confirmBtn.replaceWith(confirmBtn.cloneNode(true));
    const newConfirmBtn = document.getElementById('confirmActionBtn');

    // Attach the new callback
    newConfirmBtn.addEventListener('click', () => {
        confirmCallback();
        bootstrap.Modal.getInstance(modalEl).hide();
    }, { once: true });

    new bootstrap.Modal(modalEl).show();
}

/** Converts applicant data to CSV and triggers a download. */
function downloadCSV() {
    const data = window.currentApplicantsData;
    const position = window.currentPositionName || 'Applicants';

    if (data.length === 0) {
        showMessage('warning', 'No data to download.');
        return;
    }

    // Define CSV header and corresponding data keys
    const headers = ["First Name", "Last Name", "Email", "Phone", "Status", "Applied At"];
    const keys = ["firstname", "lastname", "email", "phone", "status", "applied_at"];

    // Convert data to CSV format
    let csvContent = headers.join(",") + "\n"; // Header row

    data.forEach(row => {
        const rowArray = keys.map(key => {
            // Retrieve value, defaulting to empty string if null/undefined
            let cell = row[key] === null || row[key] === undefined ? "" : String(row[key]);
            
            // CSV Escape logic:
            if (cell.includes(',') || cell.includes('"') || cell.includes('\n')) {
                // Escape double quotes by doubling them, and wrap cell in double quotes
                cell = '"' + cell.replace(/"/g, '""') + '"';
            }
            return cell;
        });
        csvContent += rowArray.join(",") + "\n";
    });

    // Create a Blob and trigger download
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);

    link.setAttribute("href", url);
    // Sanitize position name for filename
    const filename = `${position.replace(/[^a-zA-Z0-9\s]/g, '').replace(/\s+/g, '_')}_Applicants.csv`;
    link.setAttribute("download", filename);
    link.style.visibility = 'hidden';

    // Must append to body, click, and then remove immediately
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    showMessage('info', `Downloaded applicants for ${position}.`);
}

/* ---------------------------------------------------------------
   AJAX POST WRAPPER
---------------------------------------------------------------- */
async function sendAction(fd, buttonElement, defaultText, successMessage) {
    // If the button is not the hidden edit button, show loading state
    if (buttonElement && buttonElement.id !== 'editBtn') {
        toggleLoading(buttonElement, true, defaultText);
    }

    try {
        const res = await fetch('', { method: 'POST', body: fd });

        // First, check if the response is valid JSON
        const text = await res.text();
        let j;
        try {
            j = JSON.parse(text);
        } catch (e) {
            console.error('JSON Parse Error. Full response text:', text, e);
            showMessage('danger', 'CRITICAL ERROR: Server did not return valid JSON. This usually indicates an unexpected PHP error or HTML output before the AJAX response.');
            if (buttonElement) toggleLoading(buttonElement, false, defaultText);
            return;
        }


        if (j.ok) {
            showMessage('success', j.message || successMessage);
            // Delay reload to allow the user to see the success message
            setTimeout(() => window.location.reload(), 800);
        } else {
            showMessage('danger', j.message || 'Operation failed due to a server error.');
            if (buttonElement) toggleLoading(buttonElement, false, defaultText); // Restore button
        }
    } catch (error) {
        console.error('Fetch error:', error);
        showMessage('danger', 'Network error. Could not connect to server.');
        if (buttonElement) toggleLoading(buttonElement, false, defaultText); // Restore button
    }
}


/* ---------------------------------------------------------------
   EVENT DELEGATION: Submits and Clicks
---------------------------------------------------------------- */
document.addEventListener('submit', async (e) => {
    if (e.target.id === 'addForm') {
        e.preventDefault();
        const btn = document.getElementById('addBtn');
        const defaultText = '<i class="bi bi-plus-circle"></i> Add Position';
        const fd = new FormData(e.target);
        fd.append('action', 'add');
        await sendAction(fd, btn, defaultText, 'Position added successfully. Reloading...');
    }

    if (e.target.id === 'editForm') {
        e.preventDefault();
        const btn = document.getElementById('editBtn');
        const defaultText = 'Save Changes';
        const fd = new FormData(e.target);
        fd.append('action', 'edit');

        const m = bootstrap.Modal.getInstance(document.getElementById('editModal'));
        if (m) m.hide(); // Hide modal immediately

        // Call sendAction, which now correctly includes loading handling for the button
        await sendAction(fd, btn, defaultText, 'Position updated successfully. Reloading...');
    }
});

document.addEventListener('click', async (e) => {
    const btn = e.target.closest('button');
    if (!btn) return;

    const tr = btn.closest('tr');
    if (!tr) return; // Must be inside a table row to proceed

    // View Applicants
    if (btn.classList.contains('viewBtn')) {
        const position = tr.dataset.position;
        const body = document.getElementById('applicantsBody');
        const title = document.getElementById('applicantPosTitle');
        const downloadBtn = document.getElementById('downloadCsvBtn');

        title.textContent = position;
        body.innerHTML = '<p class="text-center text-muted"><i class="bi bi-arrow-clockwise spinner-border spinner-border-sm me-2"></i> Loading Applicants...</p>';
        downloadBtn.style.display = 'none'; // Hide button while loading

        new bootstrap.Modal(document.getElementById('applicantsModal')).show();

        // Reset global state for the new position
        window.currentApplicantsData = [];
        window.currentPositionName = position;

        const fd = new FormData();
        fd.append('action', 'fetch_applicants');
        fd.append('position', position);

        try {
            const res = await fetch('', { method: 'POST', body: fd });

            // 1. Read response as text first
            const text = await res.text();
            let j;

            // 2. Attempt to parse JSON
            try {
                j = JSON.parse(text);
            } catch (e) {
                console.error('Failed to parse JSON response during applicant fetch. Full response:', text, e);
                body.innerHTML = '<p class="text-center text-danger">Failed to load applicants: Server returned malformed data. Please verify PHP structure.</p>';
                return;
            }

            // 3. Process the parsed JSON response
            if (j.ok && j.data.length) {
                // Store data globally for CSV download
                window.currentApplicantsData = j.data;
                downloadBtn.style.display = 'inline-block'; // Show download button

                let html = `<div class="table-responsive"><table class="table table-sm table-bordered align-middle">
                    <thead class="table-light"><tr><th>Name</th><th>Email</th><th>Phone</th><th>Status</th><th>Applied At</th></tr></thead><tbody>`;
                j.data.forEach(a => {
                    const badge = (a.status === 'Hired') ? 'success' : (a.status === 'Rejected') ? 'danger' : 'secondary';
                    html += `<tr>
                      <td>${a.firstname} ${a.lastname}</td>
                      <td>${a.email}</td>
                      <td>${a.phone ?? ''}</td>
                      <td><span class="badge bg-${badge}">${a.status}</span></td>
                      <td>${a.applied_at}</td>
                    </tr>`;
                });
                html += '</tbody></table></div>';
                body.innerHTML = html;
            } else if (j.ok && !j.data.length) {
                // Explicit success but no data
                window.currentApplicantsData = [];
                downloadBtn.style.display = 'none';
                body.innerHTML = '<p class="text-center text-muted">No applicants for this position.</p>';
            } else {
                // Explicit server error returned as JSON
                window.currentApplicantsData = [];
                downloadBtn.style.display = 'none';
                body.innerHTML = `<p class="text-center text-danger">Server Error: ${j.message || 'Unknown error during fetch.'}</p>`;
            }
        } catch (error) {
            // Catches network errors
            console.error('Fetch error in viewBtn:', error);
            window.currentApplicantsData = [];
            downloadBtn.style.display = 'none';
            body.innerHTML = '<p class="text-center text-danger">Network error: Could not connect to the server.</p>';
        }
    }

    // Edit (open modal)
    if (btn.classList.contains('editBtn')) {
        document.getElementById('edit-id').value    = tr.dataset.id;
        document.getElementById('edit-name').value = tr.querySelector('.pos-name').innerText.trim();
        document.getElementById('edit-qty').value  = tr.querySelector('.pos-qty').innerText.trim();
        new bootstrap.Modal(document.getElementById('editModal')).show();
    }

    // Toggle (Uses Custom Confirmation Modal)
    if (btn.classList.contains('toggleBtn')) {
        const id = tr.dataset.id;
        const currentStatusEl = tr.querySelector('.status');
        const current = currentStatusEl.innerText.trim().toLowerCase();
        const newStatus = current === 'active' ? 'inactive' : 'active';

        const defaultText = '<i class="bi bi-power"></i>';

        showConfirmation(
            'Confirm Status Change',
            `Are you sure you want to change the status of position ID ${id} from <strong>${ucfirst(current)}</strong> to <strong>${ucfirst(newStatus)}</strong>?`,
            async () => {
                const fd = new FormData();
                fd.append('action', 'toggle');
                fd.append('id', id);
                fd.append('new_status', newStatus);
                await sendAction(fd, btn, defaultText, 'Status successfully toggled. Reloading...');
            }
        );
    }

    // Delete (Uses Custom Confirmation Modal)
    if (btn.classList.contains('delBtn')) {
        const id = tr.dataset.id;
        const name = tr.dataset.position;

        const defaultText = '<i class="bi bi-trash"></i>';

        showConfirmation(
            'Confirm Position Deletion',
            `WARNING: You are about to permanently delete the position <strong>${name}</strong> (ID: ${id}). This action cannot be undone. Continue?`,
            async () => {
                const fd = new FormData();
                fd.append('action', 'delete');
                fd.append('id', id);
                await sendAction(fd, btn, defaultText, 'Position successfully deleted. Reloading...');
            }
        );
    }
});

document.addEventListener('DOMContentLoaded', () => {
    // Attach event listener for the CSV button once the DOM is ready
    const downloadCsvBtn = document.getElementById('downloadCsvBtn');
    if (downloadCsvBtn) {
        downloadCsvBtn.addEventListener('click', downloadCSV);
    }
});

/* ---------------------------------------------------------------
   Initial Chart Draw
---------------------------------------------------------------- */
// Simple helper to capitalize the first letter
function ucfirst(str) {
    if (typeof str !== 'string' || str.length === 0) return str;
    return str.charAt(0).toUpperCase() + str.slice(1);
}
drawChart();
</script>
