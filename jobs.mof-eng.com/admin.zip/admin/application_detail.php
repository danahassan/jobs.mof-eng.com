<?php
require __DIR__ . '/../includes/auth_admin.php';
require __DIR__ . '/../db.php';
$page_title = "Applicant Details";

/* -----------------------------
   Fetch Application Info
----------------------------- */
$applicant = null;
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $application_id = (int)$_GET['id'];
    $query = "SELECT * FROM job_applications WHERE id = $application_id LIMIT 1";
    $result = $conn->query($query);
    if ($result && $result->num_rows > 0) {
        $applicant = $result->fetch_assoc();
    }
}

/* -----------------------------
   Fetch Admin Comments
----------------------------- */
$comments = [];
if (!empty($applicant['id'])) {
    $cid = (int)$applicant['id'];
    $cquery = "SELECT * FROM admin_comments WHERE application_id = $cid ORDER BY created_at DESC";
    $cres = $conn->query($cquery);
    if ($cres) {
        while ($r = $cres->fetch_assoc()) {
            $comments[] = $r;
        }
    }
}

/* -----------------------------
   Badge color helper
----------------------------- */
function get_status_badge_color($status) {
    return match ($status) {
        'Hired' => 'success',
        'Interview' => 'info',
        'Offer' => 'primary',
        'Screening' => 'warning',
        'Rejected' => 'danger',
        default => 'secondary',
    };
}

include __DIR__ . '/../includes/header.php';
?>

<style>
    .card {
        border-radius: 0.75rem;
        overflow: hidden;
    }
    .card-header {
        font-weight: 600;
        font-size: 1rem;
    }
    .highlight-header {
        background: linear-gradient(90deg, #007bff, #0056b3);
        color: #fff !important;
    }
    .info-card {
        border-top: 4px solid #198754;
    }
    label.fw-medium {
        min-width: 160px;
    }
    select.status-dropdown {
        font-weight: 600;
        border-radius: 0.4rem;
        padding: 0.3rem 0.6rem;
    }
    .comment-box {
        background: #f8f9fa;
        border-radius: 0.5rem;
        padding: 1rem;
        border: 1px solid #dee2e6;
        margin-bottom: 1rem;
    }
</style>

<div class="container py-4">
    <?php if ($applicant): ?>
        <h3 class="fw-bold mb-4 border-bottom pb-2">
            Applicant: <?= htmlspecialchars($applicant['firstname'] . ' ' . $applicant['lastname']) ?>
        </h3>

        <div class="row g-4">
            <!-- LEFT CARD -->
            <div class="col-lg-5">
                <div class="card shadow-sm">
                    <div class="card-header highlight-header">Application Summary</div>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item d-flex justify-content-between">
                            <span class="fw-medium">Position Applied For:</span>
                            <span><?= htmlspecialchars($applicant['position'] ?? 'N/A') ?></span>
                        </li>

                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <span class="fw-medium">Current Status:</span>
                            <select id="statusDropdown" class="form-select form-select-sm w-auto status-dropdown"
                                data-id="<?= $applicant['id'] ?>">
                                <?php
                                $statuses = ['New', 'Screening', 'Interview', 'Offer', 'Hired', 'Rejected'];
                                foreach ($statuses as $status) {
                                    $selected = ($status === $applicant['status']) ? 'selected' : '';
                                    echo "<option value='$status' $selected>$status</option>";
                                }
                                ?>
                            </select>
                        </li>

                        <li class="list-group-item d-flex justify-content-between">
                            <span class="fw-medium">Applied Date:</span>
                            <span><?= (new DateTime($applicant['applied_at']))->format('M d, Y H:i A') ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between">
                            <span class="fw-medium">Source:</span>
                            <span><?= htmlspecialchars($applicant['source'] ?? 'N/A') ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between">
                            <span class="fw-medium">Experience:</span>
                            <span><?= htmlspecialchars($applicant['years_experience'] ?? '—') ?> years</span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between">
                            <span class="fw-medium">Expected Salary:</span>
                            <span>$<?= htmlspecialchars($applicant['expected_salary'] ?? '—') ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between">
                            <span class="fw-medium">Age:</span>
                            <span><?= htmlspecialchars($applicant['age'] ?? '—') ?></span>
                        </li>
                    </ul>
                </div>

                <div class="mt-4">
                    <a href="/admin/applications.php" class="btn btn-dark me-2">
                        <i class="bi bi-arrow-left"></i> Back to List
                    </a>
                </div>
            </div>

            <!-- RIGHT CARD -->
            <div class="col-lg-7">
                <div class="card shadow-sm info-card mb-4">
                    <div class="card-header bg-light fw-semibold">Contact & Personal Info</div>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">
                            <label class="fw-medium">Email:</label>
                            <?= htmlspecialchars($applicant['email'] ?? 'N/A') ?>
                        </li>
                        <li class="list-group-item">
                            <label class="fw-medium">Phone:</label>
                            <?= htmlspecialchars($applicant['phone'] ?? 'N/A') ?>
                        </li>
                        <li class="list-group-item">
                            <label class="fw-medium">Address:</label>
                            <?= htmlspecialchars($applicant['address'] ?? 'N/A') ?>
                        </li>
                        <li class="list-group-item">
                            <label class="fw-medium">Message:</label>
                            <p class="mt-2 text-muted fst-italic mb-0"><?= nl2br(htmlspecialchars($applicant['message'] ?? 'No message provided.')) ?></p>
                        </li>
                        <?php if (!empty($applicant['resume_path'])): ?>
                            <li class="list-group-item">
                                <label class="fw-medium">Resume:</label>
                                <a href="/<?= htmlspecialchars($applicant['resume_path']) ?>" target="_blank" class="btn btn-sm btn-outline-success ms-2">
                                    <i class="bi bi-download"></i> Download Resume
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>

                <!-- 🟢 Admin Comments Section -->
                <div class="card shadow-sm">
                    <div class="card-header bg-success text-white fw-semibold">
                        <i class="bi bi-chat-dots"></i> Admin Comments
                    </div>
                    <div class="card-body">
                        <?php if (!empty($comments)): ?>
                            <?php foreach ($comments as $c): ?>
                                <div class="comment-box">
                                    <div class="d-flex justify-content-between">
                                        <strong><?= htmlspecialchars($c['admin_name']) ?></strong>
                                        <small class="text-muted"><?= date('M d, Y H:i', strtotime($c['created_at'])) ?></small>
                                    </div>
                                    <p class="mb-1 mt-2"><?= nl2br(htmlspecialchars($c['comment'])) ?></p>
                                    <span class="badge bg-<?= $c['visibility'] === 'public' ? 'primary' : 'secondary' ?>">
                                        <?= $c['visibility'] === 'public' ? 'Visible to Applicant' : 'Admin Only' ?>
                                    </span>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p class="text-muted fst-italic">No comments yet.</p>
                        <?php endif; ?>

                        <!-- Add new comment -->
                        <form method="post" action="save_comment.php" class="mt-3">
                            <input type="hidden" name="application_id" value="<?= $applicant['id'] ?>">
                            <div class="mb-2">
                                <textarea name="comment" class="form-control" rows="3" placeholder="Write your comment..." required></textarea>
                            </div>
                            <div class="d-flex align-items-center mb-2">
                                <label class="me-2 fw-semibold">Visibility:</label>
                                <select name="visibility" class="form-select w-auto">
                                    <option value="private">Admin Only</option>
                                    <option value="public">Visible to Applicant</option>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-success">
                                <i class="bi bi-send"></i> Add Comment
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="alert alert-danger text-center shadow-sm" role="alert">
            <h4 class="alert-heading">Application Not Found!</h4>
            <p>The applicant ID (<?= $application_id ?? 'N/A' ?>) could not be located in the database.</p>
            <hr>
            <a href="/admin/applications.php" class="btn btn-danger"><i class="bi bi-arrow-left"></i> Return to Applications List</a>
        </div>
    <?php endif; ?>
</div>

<!-- 🔄 AJAX script for status update -->
<script>
document.getElementById('statusDropdown')?.addEventListener('change', async (e) => {
    const id = e.target.dataset.id;
    const newStatus = e.target.value;
    e.target.disabled = true;

    const res = await fetch('/admin/update_status.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: `id=${id}&status=${encodeURIComponent(newStatus)}`
    });

    if (res.ok) {
        const msg = document.createElement('div');
        msg.className = 'alert alert-success mt-3';
        msg.innerHTML = `<i class="bi bi-check-circle"></i> Status updated to <b>${newStatus}</b>`;
        e.target.closest('.card').appendChild(msg);
        setTimeout(() => msg.remove(), 2500);
    } else {
        alert('❌ Failed to update status');
    }
    e.target.disabled = false;
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
