<?php
require __DIR__ . '/../includes/auth_admin.php';
require __DIR__ . '/../db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'], $_POST['status'])) {
    $id = (int)$_POST['id'];
    $status = trim($_POST['status']);

    $stmt = $conn->prepare("UPDATE job_applications SET status=? WHERE id=?");
    $stmt->bind_param("si", $status, $id);
    $ok = $stmt->execute();

    echo $ok ? "OK" : "ERROR";
}
