<?php
// /user/profile_edit.php
require __DIR__ . '/../includes/auth_user.php';
require __DIR__ . '/../db.php';
require __DIR__ . '/../includes/helpers.php';

$page_title = "Edit Profile";
include __DIR__ . '/../includes/header.php';

$uid = (int)($_SESSION['user_id'] ?? 0);

// ✅ Fetch user record
$stmt = $conn->prepare("SELECT * FROM users WHERE id=? LIMIT 1");
$stmt->bind_param("i", $uid);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$user) {
    echo '<div class="alert alert-danger mt-4 shadow-sm">User not found or session expired.</div>';
    include __DIR__ . '/../includes/footer.php';
    exit;
}

$selected = function($value, $current) {
    return $value === $current ? 'selected' : '';
};
?>

<style>
body {
  background-color: #f4f7fa;
}
.profile-wrapper {
  max-width: 1000px;
  margin: 3rem auto 5rem;
}
.profile-card {
  border: none;
  border-radius: 1rem;
  box-shadow: 0 8px 24px rgba(0,0,0,0.08);
  overflow: hidden;
  background: #fff;
}
.card-header {
  background: linear-gradient(90deg, #198754, #28a745);
  color: #fff;
  padding: 1.2rem 1.5rem;
}
.card-header h4 {
  font-weight: 700;
}
.card-body {
  padding: 2.2rem 2rem;
}
h5.section-title {
  color: #198754;
  font-weight: 700;
  border-left: 4px solid #198754;
  padding-left: .6rem;
  margin-top: 1.2rem;
  margin-bottom: 1.2rem;
}
label.form-label {
  font-weight: 600;
}
.btn-lg {
  font-size: 1.1rem;
  padding: .75rem;
  border-radius: .6rem;
}
.btn-outline-secondary:hover {
  background-color: #f8f9fa;
}
</style>

<div class="profile-wrapper">
  <div class="card profile-card">
    <div class="card-header">
      <h4 class="mb-0"><i class="bi bi-pencil-square me-2"></i>Edit Profile Information</h4>
    </div>

    <div class="card-body">
      <form method="POST" action="/user/profile_save.php">
        <input type="hidden" name="action" value="edit_contact">

        <!-- Account Info -->
        <h5 class="section-title">Account Details</h5>
        <div class="row mb-4">
          <div class="col-md-6">
            <label for="name" class="form-label">Full Name</label>
            <input type="text" class="form-control form-control-lg" id="name" name="name"
                   value="<?= e($user['name']) ?>" required>
          </div>
          <div class="col-md-6">
            <label for="email" class="form-label">Email Address</label>
            <input type="email" class="form-control form-control-lg" id="email" name="email"
                   value="<?= e($user['email']) ?>" required>
          </div>
        </div>

        <hr>

        <!-- Personal Info -->
        <h5 class="section-title">Personal & Contact Info</h5>

        <div class="row mb-4">
          <div class="col-md-3">
            <label for="areacode" class="form-label">Area Code</label>
            <input type="text" class="form-control form-control-lg" id="areacode" name="areacode"
                   value="<?= e($user['areacode']) ?>" placeholder="e.g., 964">
          </div>
          <div class="col-md-9">
            <label for="phone" class="form-label">Phone Number</label>
            <input type="text" class="form-control form-control-lg" id="phone" name="phone"
                   value="<?= e($user['phone']) ?>" placeholder="e.g., 7501234567">
          </div>
        </div>

        <div class="row mb-4">
          <div class="col-md-6">
            <label for="gender" class="form-label">Gender</label>
            <select class="form-select form-select-lg" id="gender" name="gender">
              <option value="" <?= $selected('', $user['gender']) ?>>Select Gender</option>
              <option value="male" <?= $selected('male', $user['gender']) ?>>Male</option>
              <option value="female" <?= $selected('female', $user['gender']) ?>>Female</option>
              <option value="other" <?= $selected('other', $user['gender']) ?>>Other</option>
            </select>
          </div>
          <div class="col-md-6">
            <label for="age" class="form-label">Age</label>
            <input type="number" class="form-control form-control-lg" id="age" name="age"
                   value="<?= e($user['age']) ?>" min="18" max="99" placeholder="e.g., 30">
          </div>
        </div>

        <div class="row mb-4">
          <div class="col-md-6">
            <label for="address" class="form-label">Address Line 1</label>
            <input type="text" class="form-control form-control-lg" id="address" name="address"
                   value="<?= e($user['address']) ?>" placeholder="Street Address">
          </div>
          <div class="col-md-6">
            <label for="address2" class="form-label">Address Line 2</label>
            <input type="text" class="form-control form-control-lg" id="address2" name="address2"
                   value="<?= e($user['address2']) ?>" placeholder="Apartment, suite, etc.">
          </div>
        </div>

        <div class="row mb-5">
          <div class="col-md-6">
            <label for="city" class="form-label">City</label>
            <input type="text" class="form-control form-control-lg" id="city" name="city"
                   value="<?= e($user['city']) ?>" placeholder="City Name">
          </div>
          <div class="col-md-6">
            <label for="country" class="form-label">Country</label>
            <input type="text" class="form-control form-control-lg" id="country" name="country"
                   value="<?= e($user['country']) ?>" placeholder="Country Name">
          </div>
        </div>

        <div class="d-grid gap-3">
          <button type="submit" class="btn btn-success btn-lg shadow-sm">
            <i class="bi bi-save me-2"></i>Save Changes
          </button>
          <a href="/user/dashboard.php" class="btn btn-outline-secondary btn-lg">
            <i class="bi bi-arrow-left-circle me-2"></i>Cancel and Go Back
          </a>
        </div>
      </form>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
