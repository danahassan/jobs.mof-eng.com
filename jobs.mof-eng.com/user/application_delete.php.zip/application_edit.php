<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require __DIR__ . '/../includes/auth_user.php';
require __DIR__ . '/../db.php';
require __DIR__ . '/../includes/header.php';

$app_id = (int)($_GET['id'] ?? 0);
$uid    = (int)($_SESSION['user_id'] ?? 0);

$stmt = $conn->prepare("SELECT * FROM job_applications WHERE id=? AND user_id=? LIMIT 1");
$stmt->bind_param("ii", $app_id, $uid);
$stmt->execute();
$app = $stmt->get_result()->fetch_assoc();
$stmt->close();

function h($v) {
  return htmlspecialchars($v ?? '', ENT_QUOTES, 'UTF-8');
}
?>

<?php if (!$app): ?>
  <div class="alert alert-danger m-5 text-center">
    ❌ Application not found or you don’t have permission to edit it.
  </div>
<?php else: ?>

<div class="container py-5" style="max-width:850px;">
  <h3 class="fw-bold mb-4 text-center text-dark">
    Edit Application - <?= h($app['position']) ?>
  </h3>

  <form method="post" action="application_update.php" enctype="multipart/form-data"
        class="border p-4 bg-white shadow-sm rounded-3">
    <input type="hidden" name="id" value="<?= h($app['id']) ?>">

    <div class="row g-3">
      <div class="col-md-6">
        <label class="form-label fw-semibold">First Name</label>
        <input type="text" name="firstname" class="form-control" value="<?= h($app['firstname']) ?>" required>
      </div>
      <div class="col-md-6">
        <label class="form-label fw-semibold">Last Name</label>
        <input type="text" name="lastname" class="form-control" value="<?= h($app['lastname']) ?>" required>
      </div>

      <div class="col-md-6">
        <label class="form-label fw-semibold">Email</label>
        <input type="email" name="email" class="form-control" value="<?= h($app['email']) ?>" required>
      </div>
      <div class="col-md-6">
        <label class="form-label fw-semibold">Phone</label>
        <input type="text" name="phone" class="form-control" value="<?= h($app['phone']) ?>" required>
      </div>

      <div class="col-md-4">
        <label class="form-label fw-semibold">Gender</label>
        <select name="gender" class="form-select" required>
          <?php
          $genders = ['male','female','others'];
          foreach ($genders as $g) {
              $sel = ($app['gender'] == $g) ? 'selected' : '';
              echo "<option value='$g' $sel>" . ucfirst($g) . "</option>";
          }
          ?>
        </select>
      </div>
      <div class="col-md-4">
        <label class="form-label fw-semibold">Age</label>
        <input type="number" name="age" class="form-control" value="<?= h($app['age']) ?>" required>
      </div>
      <div class="col-md-4">
        <label class="form-label fw-semibold">Start Date</label>
        <input type="date" name="startdate" class="form-control" value="<?= h($app['startdate']) ?>" required>
      </div>

      <div class="col-md-4">
        <label class="form-label fw-semibold">Years of Experience</label>
        <input type="number" name="years_experience" class="form-control"
               value="<?= h($app['years_experience']) ?>" required>
      </div>
      <div class="col-md-4">
        <label class="form-label fw-semibold">Expected Salary (USD)</label>
        <input type="number" step="0.01" name="expected_salary" class="form-control"
               value="<?= h($app['expected_salary']) ?>" required>
      </div>
      <div class="col-md-4">
        <label class="form-label fw-semibold">Source</label>
        <select name="source" class="form-select" required>
          <?php
          $sources = ['Website','LinkedIn','Referral','Walk-in','Other'];
          foreach ($sources as $src) {
              $sel = ($app['source'] == $src) ? 'selected' : '';
              echo "<option value='$src' $sel>$src</option>";
          }
          ?>
        </select>
      </div>

      <div class="col-md-6">
        <label class="form-label fw-semibold">Address</label>
        <input type="text" name="address" class="form-control" value="<?= h($app['address']) ?>" required>
      </div>
      <div class="col-md-6">
        <label class="form-label fw-semibold">Address 2 (optional)</label>
        <input type="text" name="address2" class="form-control" value="<?= h($app['address2']) ?>">
      </div>

      <div class="col-md-6">
        <label class="form-label fw-semibold">City</label>
        <input type="text" name="city" class="form-control" value="<?= h($app['city']) ?>" required>
      </div>
      <div class="col-md-6">
        <label class="form-label fw-semibold">Country</label>
        <input type="text" name="country" class="form-control" value="<?= h($app['country']) ?>" required>
      </div>

      <div class="col-md-12">
        <label class="form-label fw-semibold">Message / Cover Letter</label>
        <textarea name="message" class="form-control" rows="4" required><?= h($app['message']) ?></textarea>
      </div>

      <div class="col-md-12">
        <label class="form-label fw-semibold">Update CV (optional)</label>
        <input type="file" name="cv" class="form-control" accept=".pdf,.doc,.docx">
        <?php if (!empty($app['resume_path'])): ?>
          <p class="mt-2 small text-muted">
            Current CV:
            <a href="/<?= h($app['resume_path']) ?>" target="_blank"><?= h(basename($app['resume_path'])) ?></a>
          </p>
        <?php endif; ?>
      </div>
    </div>

    <button type="submit" class="btn btn-success w-100 mt-4">
      <i class="bi bi-save"></i> Save Changes
    </button>
  </form>
</div>

<?php endif; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
