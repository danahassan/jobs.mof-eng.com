<?php
session_start();
require __DIR__ . '/../includes/auth_user.php';
require __DIR__ . '/../db.php';

$app_id = (int)($_POST['id'] ?? 0);
$uid = (int)($_SESSION['user_id'] ?? 0);

$firstname = trim($_POST['firstname'] ?? '');
$lastname  = trim($_POST['lastname'] ?? '');
$email     = trim($_POST['email'] ?? '');
$phone     = trim($_POST['phone'] ?? '');
$gender    = trim($_POST['gender'] ?? '');
$age       = (int)($_POST['age'] ?? 0);
$startdate = trim($_POST['startdate'] ?? '');
$years_experience = (int)($_POST['years_experience'] ?? 0);
$expected_salary  = (float)($_POST['expected_salary'] ?? 0);
$source    = trim($_POST['source'] ?? '');
$address   = trim($_POST['address'] ?? '');
$address2  = trim($_POST['address2'] ?? '');
$city      = trim($_POST['city'] ?? '');
$country   = trim($_POST['country'] ?? '');
$message   = trim($_POST['message'] ?? '');

if (!$app_id || !$uid) {
    $_SESSION['flash_error'] = "Invalid request.";
    header("Location: /user/dashboard.php");
    exit;
}

$upload_dir = __DIR__ . '/../uploads/';
if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);

$new_cv_filename = null;
$new_resume_path = null;

if (!empty($_FILES['cv']['name'])) {
    $ext = strtolower(pathinfo($_FILES['cv']['name'], PATHINFO_EXTENSION));
    $allowed = ['pdf','doc','docx'];
    if (in_array($ext, $allowed)) {
        $new_cv_filename = uniqid('cv_', true) . '.' . $ext;
        $new_resume_path = 'uploads/' . $new_cv_filename;
        move_uploaded_file($_FILES['cv']['tmp_name'], $upload_dir . $new_cv_filename);
    } else {
        $_SESSION['flash_error'] = "Invalid CV format.";
        header("Location: /user/application_edit.php?id=$app_id");
        exit;
    }
}

if ($new_cv_filename) {
    $stmt = $conn->prepare("
        UPDATE job_applications
        SET firstname=?, lastname=?, email=?, phone=?, gender=?, age=?, startdate=?, years_experience=?, expected_salary=?, source=?, address=?, address2=?, city=?, country=?, message=?, resume_path=?, cv_filename=?
        WHERE id=? AND user_id=?
    ");
    $stmt->bind_param("sssssisidssssssssii",
        $firstname, $lastname, $email, $phone, $gender, $age, $startdate, $years_experience,
        $expected_salary, $source, $address, $address2, $city, $country, $message,
        $new_resume_path, $new_cv_filename, $app_id, $uid
    );
} else {
    $stmt = $conn->prepare("
        UPDATE job_applications
        SET firstname=?, lastname=?, email=?, phone=?, gender=?, age=?, startdate=?, years_experience=?, expected_salary=?, source=?, address=?, address2=?, city=?, country=?, message=?
        WHERE id=? AND user_id=?
    ");
    $stmt->bind_param("sssssisidssssssii",
        $firstname, $lastname, $email, $phone, $gender, $age, $startdate, $years_experience,
        $expected_salary, $source, $address, $address2, $city, $country, $message, $app_id, $uid
    );
}

if ($stmt->execute()) {
    $_SESSION['flash_success'] = "✅ Application updated successfully!";
} else {
    $_SESSION['flash_error'] = "❌ Update failed: " . htmlspecialchars($stmt->error);
}
$stmt->close();

header("Location: /user/dashboard.php");
exit;
