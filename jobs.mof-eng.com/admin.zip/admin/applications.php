<?php
require __DIR__ . '/../includes/auth_admin.php';
require __DIR__ . '/../db.php';
$page_title = "Admin Dashboard";

// --- START: Dashboard Logic Improvement ---
// Function to safely fetch a single count from the database
function fetch_count($conn, $query) {
    $result = $conn->query($query);
    // Use proper checking for result and fetch_assoc
    $row = $result ? $result->fetch_assoc() : null;
    return (int)($row['c'] ?? 0);
}

// Fetching key performance indicators using the new function
$k_total = fetch_count($conn, "SELECT COUNT(*) c FROM job_applications");
$k_7d = fetch_count($conn, "SELECT COUNT(*) c FROM job_applications WHERE applied_at >= (NOW() - INTERVAL 7 DAY)");
$k_hired = fetch_count($conn, "SELECT COUNT(*) c FROM job_applications WHERE status='Hired'");
$k_interview = fetch_count($conn, "SELECT COUNT(*) c FROM job_applications WHERE status='Interview'");

// --- NEW: Fetch recent applications for the table ---
$applications_query = "SELECT id, firstname, lastname, position, status, applied_at FROM job_applications ORDER BY applied_at DESC LIMIT 10";
$applications_result = $conn->query($applications_query);
$applications = [];
if ($applications_result) {
    while ($row = $applications_result->fetch_assoc()) {
        $applications[] = $row;
    }
}
// --- END: Fetch recent applications ---

// --- END: Dashboard Logic Improvement ---

include __DIR__ . '/../includes/header.php';

// Define status colors for badges
function get_status_badge_color($status) {
    return match ($status) {
        'Hired' => 'success',
        'Interview' => 'info',
        'Offer' => 'primary',
        'Screening' => 'warning',
        'Rejected' => 'danger',
        default => 'secondary',
    };
}

// Map status names to a cleaner display name for KPI cards
function get_kpi_card_theme($status) {
    // Note: 'Total Applications' is handled separately in the HTML for the specific 'bg-light' style
    return match ($status) {
        'New (7d)' => 'border-info text-info',
        'Interview Stage' => 'border-warning text-warning',
        'Hired' => 'border-success text-success',
        default => 'border-secondary text-secondary',
    };
}
?>
<h3 class="fw-bold mb-5 border-bottom pb-2">Admin Dashboard</h3>

<div class="row g-4 mb-5">
    
    <div class="col-sm-6 col-lg-3">
        <div class="card shadow-sm h-100 bg-light border-primary text-primary">
            <div class="card-header bg-transparent fw-semibold border-bottom-0">Total Applications</div>
            <div class="card-body">
                <div class="fs-2 fw-bolder"><?= $k_total ?></div>
            </div>
        </div>
    </div>
    
    <div class="col-sm-6 col-lg-3">
        <div class="card shadow-sm h-100 <?= get_kpi_card_theme('New (7d)') ?>">
            <div class="card-header bg-white fw-semibold border-bottom-0">New (7d)</div>
            <div class="card-body">
                <div class="fs-2 fw-bolder"><?= $k_7d ?></div>
            </div>
        </div>
    </div>
    
    <div class="col-sm-6 col-lg-3">
        <div class="card shadow-sm h-100 <?= get_kpi_card_theme('Interview Stage') ?>">
            <div class="card-header bg-white fw-semibold border-bottom-0">Interview Stage</div>
            <div class="card-body">
                <div class="fs-2 fw-bolder"><?= $k_interview ?></div>
            </div>
        </div>
    </div>
    
    <div class="col-sm-6 col-lg-3">
        <div class="card shadow-sm h-100 <?= get_kpi_card_theme('Hired') ?>">
            <div class="card-header bg-white fw-semibold border-bottom-0">Hired</div>
            <div class="card-body">
                <div class="fs-2 fw-bolder"><?= $k_hired ?></div>
            </div>
        </div>
    </div>
</div>
<div class="row g-4 mb-5">
    <div class="col-lg-6">
        <div class="card shadow-sm">
            <div class="card-header bg-white fw-semibold border-bottom-0">Applications By Status</div>
            <div class="card-body p-0">
                <div id="by_status"></div>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card shadow-sm">
            <div class="card-header bg-white fw-semibold border-bottom-0">Applications By Source</div>
            <div class="card-body p-0">
                <div id="by_source"></div>
            </div>
        </div>
    </div>
</div>
<div class="card shadow-lg">
    <div class="card-header text-bg-dark fw-bold d-flex justify-content-between align-items-center py-3">
        Latest 10 Applications
        <a href="/admin/applications.php" class="btn btn-sm btn-outline-light fw-bold">View All & Manage <i class="bi bi-arrow-right"></i></a>
    </div>
    <div class="card-body p-0">
        <?php if (!empty($applications)): ?>
            <div class="table-responsive">
                <table class="table table-striped table-hover align-middle mb-0">
                    <thead class="table-secondary">
                        <tr>
                            <th scope="col" class="py-3">#</th>
                            <th scope="col" class="py-3">Applicant</th>
                            <th scope="col" class="py-3">Position</th>
                            <th scope="col" class="py-3">Applied At</th>
                            <th scope="col" class="py-3">Status</th>
                            <th scope="col" class="py-3">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($applications as $app): ?>
                        <tr>
                            <th scope="row"><?= $app['id'] ?></th>
                            <td><?= htmlspecialchars($app['firstname'] . ' ' . $app['lastname']) ?></td>
                            <td><?= htmlspecialchars($app['position'] ?? 'N/A') ?></td>
                            <td class="text-muted"><?= (new DateTime($app['applied_at']))->format('M d, Y') ?></td>
                            <td><span class="badge text-bg-<?= get_status_badge_color($app['status']) ?> rounded-pill py-2 px-3"><?= htmlspecialchars($app['status']) ?></span></td>
                            <td>
                                <a href="/admin/application_detail.php?id=<?= $app['id'] ?>" class="btn btn-sm btn-outline-secondary" title="View Details">
                                    <i class="bi bi-arrow-right-short"></i> View
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="p-5 text-center text-muted">No recent applications found.</div>
        <?php endif; ?>
    </div>
</div>
<script>
(async ()=>{
    // This assumes the file /admin_stats.php exists and returns the JSON data required.
    const res = await fetch('/admin_stats.php'); 
    const d = await res.json();
    
    // Function to render the stats lists
    function listToUl(id, labels, values){
        let html = '<ul class="list-group list-group-flush">';
        for(let i=0;i<labels.length;i++){
            html += `<li class="list-group-item d-flex justify-content-between align-items-center py-3">
                <span class="fw-medium">${labels[i]}</span>
                <span class="badge text-bg-dark rounded-pill fs-6 px-3 py-2">${values[i]}</span>
            </li>`;
        }
        html += '</ul>'; 
        document.getElementById(id).innerHTML = html;
    }
    
    if (d.by_status && d.by_source) {
        listToUl('by_status', d.by_status.labels, d.by_status.values);
        listToUl('by_source', d.by_source.labels, d.by_source.values);
    }
})();
</script>
<?php include __DIR__ . '/../includes/footer.php'; ?>